
  # Panda School for Kids

  This is a code bundle for Panda School for Kids. The original project is available at https://www.figma.com/design/LHzaWlveP95FKxxQ2WPTW0/Panda-School-for-Kids.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  